package performance.com.ng.hptc

object Constants {
    const val USER_NAME: String= "user_name"
    const val TOTAL_QUESTIONS: String= "total_answers"
    const val CORRECT_ANSWERS: String= "correct_answers"


    fun getQuestions(): ArrayList<Questions>{
        val questionsList = ArrayList<Questions>()

        val q1= Questions(
            1,
            "______the process of identifying problems, figuring out solutions, acquiring resources to build the solutions, and managing the required activities.",
            "Organization",
            "Management",
            "Entrepreneurship",
            "Corporate Strategy",
            3)
        questionsList.add(q1)

        val q2= Questions(
            2,
            "The business model where you sell goods or services of sufficient quality at a lower price than the other options available to customers is called ___",
            "Marketplace Business Model",
            "Operation Efficiency",
            "Product Leadership",
            "Customer Intimacy",
            2)
        questionsList.add(q2)

        val q3= Questions(
            3,
            "All Business lessons are learned in_______",
            "Business Schools",
            "Interaction with customers",
            "On the Streets",
            "All of the above",
            4)
        questionsList.add(q3)

        val q4= Questions(
            4,
            "What do you call the people that purchase your company’s product or service?",
            "Staffs",
            "Customers",
            "Shareholders",
            "Investor",
            2)
        questionsList.add(q4)

        val q5= Questions(
            5,
            "Business Disciplines include the following except ___",
            "Finance",
            "Sales",
            "Marketing",
            "Cyptocurrency",
            4)
        questionsList.add(q5)

        val q6= Questions(
            6,
            "Which of these actions is wrong on a business plan?",
            "Reviewing it",
            "Following it through",
            "Pitching it to investors",
            "Hiding and Keeping it",
            4 )
        questionsList.add(q6)

        val q7= Questions(
            7,
            "A competitor is any business that addresses the problem that your customer has. Competitor come from ______",
            "Neighbouring Towns",
            "Neighbouring Streets",
            "All over the world",
            "Within the country", 3)
        questionsList.add(q7)

        val q8= Questions(8,
            "Failure in any major area of business will undermine the company, possibly causing it to fail.\n" +
                    "You cannot do everything. That is why you need to hire people. How true is the statement",
            "Completely true",
            "Completely false",
            "Sometimes true",
            "It depends", 1)
        questionsList.add(q8)


        val q9= Questions(
            9,
            "Financial Reporting in the business enable entrepreneurs to visualize, foresee, analyze and prevent risks in their businesses. ",
            "Strongly Agree",
            "Agree",
            "Disagree ",
            "Strongly Disagree",
            1)
        questionsList.add(q9)

        val q10= Questions(
            10,
            "The business model where you allow different groups with mutual interest to interact, creating opportunities for business transactions.",
            "Marketplace Business Model",
            "Operation Efficiency",
            "Product Leadership",
            "Customer Intimacy",
            1)
        questionsList.add(q10)

        val q11= Questions(
            11,
            "Which of these types of entrepreneurship saves resources and efforts most for the entrepreneur, by helping to streamline focus on market reality.",
            "Resources-first entrepreneurship",
            "Idea-first entrepreneurship",
            "Problem-first entrepreneurship",
            "Money-first entrepreneurship",
            3)
        questionsList.add(q11)

        val q12= Questions(
            12,
            "The business model where you know everything about the customer and are constantly collecting more information to better serve them.",
            "Marketplace Business Model",
            "Operation Efficiency",
            "Product Leadership",
            "Customer Intimacy",
            4)
        questionsList.add(q12)

        val q13= Questions(
            13,
            "What is the best solution out there right now and Why? What would make the current solution you use better? These questions are good to ask _______ ",
            "Staffs",
            "Customers",
            "Shareholders",
            "Investor",
            2)
        questionsList.add(q13)


        val q14= Questions(
            14,
            "COST ESTIMATE: You need 2 workers to assist you to complete a project which usually takes 5 days. If each worker cost \$10 per day and other raw materials needed throughout cost \$20. How much is the total cost of production?",
            "\$100",
            "\$200",
            "\$120",
            "\$210",
            3)
        questionsList.add(q14)

        val q15= Questions(
            15,
            "MARKET CALCULATION: If 30% of the 3000 population in your community are farmers, and 10% of these farmers are crop farmers, how many people are in your market as a fertilizer seller?",
            "90",
            "900",
            "3000",
            "2960",
            1)
        questionsList.add(q15)

        val q16= Questions(
            16,
            "What is the formal document that describes the work to be done for a specific project?",
            "Standard Operating Procedure",
            "Price Quotation",
            "Scope of Work",
            "Invoice",
            3)
        questionsList.add(q16)

        val q17= Questions(
            17,
            "To define your__________You must answer:“Why your customer give you money, and not someone else?",
            "Market",
            "Value Proposition",
            "Sales",
            "Financial Projection",
            2)
        questionsList.add(q17)

        val q18= Questions(
            18,
            "Most new companies fail because they commit to a particular product or service too early before they really understand customers or the size of the market.",
            "Completely true",
            "Completely false",
            "Sometimes true",
            "It depends", 1)
        questionsList.add(q18)

        val q19= Questions(
            19,
            "The business model where you create goods or services that redefine the market and often offer new features or benefits",
            "Marketplace Business Model",
            "Operation Efficiency",
            "Product Leadership",
            "Customer Intimacy",
            3)
        questionsList.add(q19)

        val q20= Questions(
            20,
            "Going outside and talking a lot about your ideas to people who you think have the problem you want to solve is called_______",
            "Problem-first entrepreneurship",
            "Resources-first entrepreneurship",
            "Idea-first entrepreneurship",
            "Money-first entrepreneurship",
            1)
        questionsList.add(q20)


        return questionsList
    }
}