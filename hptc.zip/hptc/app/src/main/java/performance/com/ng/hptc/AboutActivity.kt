package performance.com.ng.hptc

import androidx.appcompat.app.AppCompatActivity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlin.system.exitProcess

class AboutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)

        val mButton = findViewById<Button>(R.id.button_1)

        // When button is clicked, ALertDialog
        // is created and displayed
        mButton.setOnClickListener {
            val mBuilder = AlertDialog.Builder(this)
                .setTitle("Confirm")
                .setMessage("Are you sure you want to exit?")
                .setPositiveButton("Yes", null)
                .setNegativeButton("No", null)
                .show()

            // Function for the positive button
            // is programmed to exit the application
            val mPositiveButton = mBuilder.getButton(AlertDialog.BUTTON_POSITIVE)
            mPositiveButton.setOnClickListener {
                exitProcess(0)
            }}

        val btnShare =  findViewById(R.id.btnShare) as Button

        btnShare.setOnClickListener {
            val email = "mayowalala@gmail.com"
            val subject = "High Performance Business Quiz"
            val message = "Reinvent yourself today, Sign Up with HPTC to attend executive Business Lesson"

            shareMessage(email, subject, message) }


        val gobackbutton = findViewById(R.id.goback) as Button
        gobackbutton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }

    private fun shareMessage(email: String, subject: String, message: String) {
        val mIntent = Intent(Intent.ACTION_SEND)
        mIntent.data = Uri.parse("mailto")
        mIntent.type = "text/plain"

        mIntent.putExtra(Intent.EXTRA_EMAIL, email)
        mIntent.putExtra(Intent.EXTRA_SUBJECT, subject)
        mIntent.putExtra(Intent.EXTRA_TEXT, message)

        try {
            startActivity(Intent.createChooser(mIntent, "choose email client..."))
            return
        } catch (e: Exception) {
            Toast.makeText(this@AboutActivity, "Incomplete Information", Toast.LENGTH_SHORT).show()
        }


    }
}