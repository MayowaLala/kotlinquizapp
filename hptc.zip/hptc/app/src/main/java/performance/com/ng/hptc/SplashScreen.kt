package performance.com.ng.hptc

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.logging.Handler


class SplashScreen : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_splash_screen)

        val launcher = findViewById(R.id.launcher) as ImageView

        launcher.alpha = 0f
        launcher.animate().setDuration(4000).alpha(1f).withEndAction{

            val intent = Intent(this, MainActivity::class.java)

            startActivity(intent)

            finish()
        }



        }

    }
