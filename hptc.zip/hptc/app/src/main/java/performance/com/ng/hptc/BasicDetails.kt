package performance.com.ng.hptc

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_basic_details.*
import kotlin.system.exitProcess


class BasicDetails : AppCompatActivity(), View.OnClickListener {

    private var mCurrentposition: Int = 1
    private var mQuestionsList : ArrayList<Questions>? = null
    private var mSelectedOptionPosition : Int = 0
    private var mCorrectAnswers: Int = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_basic_details)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN

        val mButton = findViewById<Button>(R.id.button_1)

        // When button is clicked, ALertDialog
        // is created and displayed
        mButton.setOnClickListener {
            val mBuilder = AlertDialog.Builder(this)
                .setTitle("Confirm")
                .setMessage("Are you sure you want to exit?")
                .setPositiveButton("Yes", null)
                .setNegativeButton("No", null)
                .show()

            // Function for the positive button
            // is programmed to exit the application
            val mPositiveButton = mBuilder.getButton(AlertDialog.BUTTON_POSITIVE)
            mPositiveButton.setOnClickListener {
                exitProcess(0)
            }}







        mQuestionsList = Constants.getQuestions()

        setQuestions()

        option1.setOnClickListener(this)
        option2.setOnClickListener(this)
        option3.setOnClickListener(this)
        option4.setOnClickListener(this)
        btn_submit.setOnClickListener(this)

    }

    private fun setQuestions(){

        val question = mQuestionsList!! [mCurrentposition - 1]


        defaultOptionsView()

        if (mCurrentposition == mQuestionsList!!.size)
        { btn_submit.text = "FINISH"}
        else   { btn_submit.text = "SUBMIT"}


        progressBar.progress = mCurrentposition
        tvProgress.text = "$mCurrentposition" + "/" + progressBar.max
        tv_question.text = question!!.question

        option1.text = question.option1
        option2.text = question.option2
        option3.text = question.option3
        option4.text = question.option4

    }

    private fun defaultOptionsView() {
        val options = ArrayList<TextView>()
        options.add(0, option1)
        options.add(1, option2)
        options.add(2, option3)
        options.add(3, option4)


        for (option in options)
        {
            option.setTextColor(Color.parseColor("#7A8089"))
            option.typeface = Typeface.DEFAULT
            option.background = ContextCompat.getDrawable(this, R.drawable.defaultoption)
        }
    }

    override fun onClick(v: View?) {
        when (v?.id){
            R.id.option1 ->{
                selectedOptionView(option1, 1)
            }
            R.id.option2 -> {
                selectedOptionView(option2, 2)
            }
            R.id.option3 ->{
                selectedOptionView(option3,  3)
            }
            R.id.option4 ->{
                selectedOptionView(option4, 4)
            }
            R.id.btn_submit -> {
                if (mSelectedOptionPosition == 0) {
                    mCurrentposition ++

                    when { mCurrentposition <= mQuestionsList!!.size ->{

                        setQuestions()
                    } else -> {
                        val intent = Intent (this, ResultActivity::class.java)
                        intent.putExtra(Constants.CORRECT_ANSWERS, mCorrectAnswers)
                        intent.putExtra(Constants.TOTAL_QUESTIONS, mQuestionsList!!.size)
                        startActivity(intent)
                    }
                    }
                }  else{
                    val question = mQuestionsList?.get(mCurrentposition - 1)
                        if (question!!.correctAnswer != mSelectedOptionPosition)
                        { answerView(mSelectedOptionPosition, R.drawable.wrongoption)
                        } else {
                            mCorrectAnswers++

                            answerView(mSelectedOptionPosition, R.drawable.correctoption)
                        }

                     if (mCurrentposition == mQuestionsList!!.size){

                             btn_submit.text = "FINISH" }
                         else {
                             btn_submit.text = "PLEASE PROCEED"}

                    mSelectedOptionPosition = 0
                }

            }
        }
    }






    private fun answerView (answer: Int, drawableView: Int){
        when (answer){ 1 ->{option1.background = ContextCompat.getDrawable(this, drawableView) }
                        2 ->{option2.background = ContextCompat.getDrawable(this, drawableView) }
                        3 ->{option3.background = ContextCompat.getDrawable(this, drawableView) }
                        4 ->{option4.background = ContextCompat.getDrawable(this, drawableView) }
        }
    }
    private fun selectedOptionView( tv: TextView, selectedoptionNum: Int) {

        defaultOptionsView()
        mSelectedOptionPosition = selectedoptionNum

        tv.setTextColor(Color.parseColor("#363A43"))
        tv.setTypeface( tv.typeface, Typeface.BOLD )
        tv.background = ContextCompat.getDrawable(this, R.drawable.selectedoption)



    }


}