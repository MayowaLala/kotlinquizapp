package performance.com.ng.hptc


import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.google.android.material.textfield.TextInputEditText
import kotlinx.android.synthetic.main.activity_result.*
import org.w3c.dom.Text
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //MY CODE STARTS HERE

        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN


        val mButton = findViewById<Button>(R.id.button_1)

        // When button is clicked, ALertDialog
        // is created and displayed
        mButton.setOnClickListener {
            val mBuilder = AlertDialog.Builder(this)
                .setTitle("Confirm")
                .setMessage("Are you sure you want to exit?")
                .setPositiveButton("Yes", null)
                .setNegativeButton("No", null)
                .show()

            // Function for the positive button
            // is programmed to exit the application
            val mPositiveButton = mBuilder.getButton(AlertDialog.BUTTON_POSITIVE)
            mPositiveButton.setOnClickListener {
                exitProcess(0)
            }}






        val first_course = findViewById(R.id.first_course) as LinearLayout
        first_course.setOnClickListener {
            val intent = Intent(this, BasicDetails::class.java)
            startActivity(intent)
        }

        val aboutbtn = findViewById(R.id.second_course) as LinearLayout
        aboutbtn.setOnClickListener {
            val intent = Intent(this, AboutActivity::class.java)
            startActivity(intent)
        }

        val premiumButton = findViewById(R.id.third_course) as LinearLayout

        premiumButton.setOnClickListener{
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.performance.com.ng/7figuresalary"))
            startActivity(i)
        }


        val btnShare = findViewById(R.id.fourth_course) as LinearLayout

        btnShare.setOnClickListener {
            val email = "mayowalala@gmail.com"
            val subject = "High Performance Business Quiz"
            val message =
                "Reinvent yourself today, Sign Up with HPTC to attend executive Business Lesson"
            shareMessage(email, subject, message)
        }

    }



    private fun shareMessage(email: String, subject: String, message: String) {
        val mIntent = Intent(Intent.ACTION_SEND)
        mIntent.data = Uri.parse("mailto")
        mIntent.type = "text/plain"

        mIntent.putExtra(Intent.EXTRA_EMAIL, email)
        mIntent.putExtra(Intent.EXTRA_SUBJECT, subject)
        mIntent.putExtra(Intent.EXTRA_TEXT, message)

        try {
            startActivity(Intent.createChooser(mIntent, "choose email client..."))
            return
        } catch (e: Exception) {
            Toast.makeText(this@MainActivity, "Incomplete Information", Toast.LENGTH_SHORT).show()
        }

    }
}